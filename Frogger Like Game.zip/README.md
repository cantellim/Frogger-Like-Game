frontend-nanodegree-arcade-game
===============================

How to Play the Game

* Use the up, down, left and right keys to move the player.
* Try to make it to the water
* Don't get hit by the bugs or you will have to start over


Installation

* Download the zipfile to your computer
* Unzip the file
* Doubleclick on index.html to play the game. 